package com.example.batchdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
